package HawaiiCarbonTracking.src;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class LoginServer {

    private static final int PORT = 8080;

    public static void startServer() {
        try {
            HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
            // Context for login handling
            server.createContext("/login", new LoginHandler());
            // Context to serve the login.html file
            server.createContext("/login.html", new StaticFileHandler("login.html"));
            // You can add contexts for home.html, discover.html, profile.html, etc.
            server.setExecutor(null);
            server.start();
            System.out.println("Server started at http://localhost:" + PORT + "/login.html");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Handler for processing login POST requests
    static class LoginHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }
            
            // Read URL-encoded form data from the request body
            String body = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))
                    .lines().collect(Collectors.joining("\n"));
            Map<String, String> params = parseQuery(body);
            String username = params.get("username");
            String password = params.get("password");
            
            boolean isValid = UserAuthenticator.verifyUser(username, password);
            
            String response;
            if (isValid) {
                response = "<html><body><h1>Login successful!</h1><p>Welcome, " + username + ".</p></body></html>";
            } else {
                response = "<html><body><h1>Login failed!</h1><p>Invalid credentials.</p></body></html>";
            }
            
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            byte[] respBytes = response.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, respBytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(respBytes);
            os.close();
        }
    }

    // Handler to serve static HTML files
    static class StaticFileHandler implements HttpHandler {
        private final String fileName;
        
        public StaticFileHandler(String fileName) {
            this.fileName = fileName;
        }
        
        public void handle(HttpExchange exchange) throws IOException {
            File file = new File(fileName);
            if (!file.exists()) {
                String notFound = "404 Not Found";
                exchange.sendResponseHeaders(404, notFound.length());
                OutputStream os = exchange.getResponseBody();
                os.write(notFound.getBytes());
                os.close();
                return;
            }
            byte[] bytes = new byte[(int) file.length()];
            try (FileInputStream fis = new FileInputStream(file)) {
                fis.read(bytes);
            }
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(bytes);
            os.close();
        }
    }
    
    // Utility method to parse URL-encoded query string
    public static Map<String, String> parseQuery(String query) throws UnsupportedEncodingException {
        Map<String, String> result = new HashMap<>();
        if (query == null || query.isEmpty()) {
            return result;
        }
        for (String param : query.split("&")) {
            String[] parts = param.split("=", 2);
            String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8.name());
            String value = parts.length > 1 ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8.name()) : "";
            result.put(key, value);
        }
        return result;
    }
    
    public static void main(String[] args) {
        startServer();
    }
}
