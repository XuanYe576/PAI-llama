package HawaiiCarbonTracking.src;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CollaboratorAPI {
    public static boolean sendRewardToken(String token) {
        try {
            URL url = new URL("https://collaboratorapi.com/rewards");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.getOutputStream().write(("token=" + token).getBytes());

            return conn.getResponseCode() == 200;
        } catch (Exception e) {
            System.out.println("API error: " + e.getMessage());
            return false;
        }
    }
}
