package HawaiiCarbonTracking.src;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class UserAuthenticator {
    public static boolean verifyUser(String username, String password) {
        // Option 1: Verify against a CSV file (assumes file "data/UserCred.csv")
        try {
            Scanner scanner = new Scanner(new File("data/UserCred.csv"));
            while (scanner.hasNextLine()) {
                String[] parts = scanner.nextLine().split(",");
                if (parts.length >= 2 && parts[0].trim().equals(username) && parts[1].trim().equals(password)) {
                    scanner.close();
                    return true;
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("UserCred.csv not found.");
        }
        
        // Option 2: Hardcode a sample user (for testing)
        // if (username.equals("admin") && password.equals("password")) return true;
        
        return false;
    }
}
