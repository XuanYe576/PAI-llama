package HawaiiCarbonTracking.src;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class RewardGenerator {
    public static String generateToken(String username, double emissionReduction) {
        String data = username + emissionReduction + System.currentTimeMillis();
        return hashSHA256(data);
    }

    private static String hashSHA256(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating hash", e);
        }
    }
}
