package HawaiiCarbonTracking.src;

import java.sql.*;

public class Database {
    private static final String URL = "jdbc:sqlite:data/hawaii_carbon.db";

    public static void initialize() {
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {
            
            String usersTable = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)";
            String activityTable = "CREATE TABLE IF NOT EXISTS activities (id INTEGER PRIMARY KEY, username TEXT, activity TEXT, distance REAL, timestamp TEXT)";
            String rewardsTable = "CREATE TABLE IF NOT EXISTS rewards (id INTEGER PRIMARY KEY, username TEXT, token TEXT, confirmed INTEGER)";

            stmt.execute(usersTable);
            stmt.execute(activityTable);
            stmt.execute(rewardsTable);
            
        } catch (SQLException e) {
            System.out.println("Database initialization error: " + e.getMessage());
        }
    }

    public static boolean storeActivity(String username, String activity, double distance) {
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO activities (username, activity, distance, timestamp) VALUES (?, ?, ?, datetime('now'))")) {
            stmt.setString(1, username);
            stmt.setString(2, activity);
            stmt.setDouble(3, distance);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error storing activity: " + e.getMessage());
            return false;
        }
    }

    public static boolean storeReward(String username, String token) {
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO rewards (username, token, confirmed) VALUES (?, ?, 0)")) {
            stmt.setString(1, username);
            stmt.setString(2, token);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error storing reward: " + e.getMessage());
            return false;
        }
    }
}
