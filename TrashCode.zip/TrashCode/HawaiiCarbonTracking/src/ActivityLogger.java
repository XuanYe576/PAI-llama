package HawaiiCarbonTracking.src;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class ActivityLogger {
    public static void logActivity(String username, String activity) {
        try (FileWriter writer = new FileWriter("activity_log.csv", true)) {
            writer.append(username).append(",").append(activity).append(",").append(LocalDateTime.now().toString()).append("\n");
        } catch (IOException e) {
            System.out.println("Error logging activity: " + e.getMessage());
        }
    }
}
