package HawaiiCarbonTracking.src;

import java.util.HashMap;
import java.util.Map;

public class CarbonFootprintCalculator {
    private static final Map<String, Double> emissionFactors = new HashMap<>();

    static {
        emissionFactors.put("car", 0.24);
        emissionFactors.put("bike", 0.02);
        emissionFactors.put("walk", 0.0);
    }

    public static double calculateEmission(String activity, double distance) {
        return emissionFactors.getOrDefault(activity, 0.0) * distance;
    }
}
