package HawaiiCarbonTracking.src;

public class ImpactEvaluator {
    private static final double REWARD_THRESHOLD = 10.0; // Threshold in kg CO2 saved

    public static boolean qualifiesForReward(double emissionReduction) {
        return emissionReduction >= REWARD_THRESHOLD;
    }
}
